

#include<stdio.h>
int main()
{
    int s,a,b,c;
    scanf("%d %d %d",&a,&b,&c);
    s=a+b+c;
    if(s==180)
        printf("traingle is valid");
   else printf("traingle is not valid");
    return 0;


}
