#include<stdio.h>
int main()
{
    int i,j,n;
    scanf("%d",&n);
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {
            if(i%2==0&&j%2==0)//even
                printf("1");
            else if(i%2!=0&&j%2!=0)//odd
                printf("1");
                else printf("0");
        }
        printf("\n");
    }
}
