#include<stdio.h>

int main()
{
    int n,i;
    scanf("%d",&n);
     system("cls");
    for(i=1;i<=10;i++)
    {
        printf("%d X %d = %d \n",n,i,n*i);
    }

    return 0;
}
